package com.su.service.impl;

import com.su.service.SlotService;
import org.springframework.stereotype.Service;

@Service("slotService")
public class SlotServiceImpl implements SlotService {
}
