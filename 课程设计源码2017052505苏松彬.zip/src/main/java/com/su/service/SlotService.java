package com.su.service;

public interface SlotService {
}
